<?php

$host = 'localhost';
$nama = 'root';
$pass = '';
$db = 'uang';

$koneksi = mysqli_connect($host, $nama, $pass, $db);
?>